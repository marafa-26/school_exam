import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

void main() => runApp(const SchoolExamApp());

class SchoolExamApp extends StatelessWidget {
  const SchoolExamApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'School Exams',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0D1B6E)),
        scaffoldBackgroundColor: const Color(0xFFF4F6FB),
        appBarTheme: AppBarTheme(
          backgroundColor: const Color(0xFF0D1B6E),
          foregroundColor: Colors.white,
          elevation: 0,
          titleTextStyle: GoogleFonts.poppins(
              fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white),
          iconTheme: const IconThemeData(color: Colors.white),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

// ══════════════════════════════════════════════════════
//  COULEURS
// ══════════════════════════════════════════════════════
class AppColors {
  AppColors._();
  static const Color primary = Color(0xFF0D1B6E);
  static const Color background = Color(0xFFF4F6FB);
  static const LinearGradient gradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF0D1B6E), Color(0xFF1A3A8F), Color(0xFF1565C0)],
  );
}

// ══════════════════════════════════════════════════════
//  EN-TÊTE DE SECTION
// ══════════════════════════════════════════════════════
Widget _buildSectionHeader(String title, String subtitle) {
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
    decoration: const BoxDecoration(gradient: AppColors.gradient),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: GoogleFonts.poppins(
                fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white)),
        const SizedBox(height: 3),
        Text(subtitle,
            style: GoogleFonts.poppins(fontSize: 12, color: Colors.white70)),
      ],
    ),
  );
}

// ══════════════════════════════════════════════════════
//  BARRE DE RECHERCHE RÉUTILISABLE
// ══════════════════════════════════════════════════════
Widget _buildSearchBar(
    TextEditingController ctrl, String hint, VoidCallback onClear, Function(String) onChanged) {
  return Padding(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
    child: TextField(
      controller: ctrl,
      onChanged: onChanged,
      style: GoogleFonts.poppins(fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: GoogleFonts.poppins(fontSize: 14, color: Colors.grey[400]),
        prefixIcon: const Icon(Icons.search_rounded, color: AppColors.primary),
        suffixIcon: ctrl.text.isNotEmpty
            ? IconButton(
                icon: const Icon(Icons.clear_rounded, color: Colors.grey),
                onPressed: onClear)
            : null,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 8,
              offset: const Offset(0, 3))
        ],
      ),
    ),
  );
}

// ══════════════════════════════════════════════════════
//  WIDGET : AUCUN RÉSULTAT
// ══════════════════════════════════════════════════════
Widget _buildNoResult() {
  return Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.search_off_rounded, size: 64, color: Colors.grey),
        const SizedBox(height: 12),
        Text('Aucune matière trouvée',
            style: GoogleFonts.poppins(fontSize: 16, color: Colors.grey)),
        const SizedBox(height: 6),
        Text('Essaie un autre mot-clé',
            style: GoogleFonts.poppins(fontSize: 13, color: Colors.grey[400])),
      ],
    ),
  );
}

// ══════════════════════════════════════════════════════
//  SPLASH SCREEN
// ══════════════════════════════════════════════════════
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200));
    _fade = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeIn));
    _scale = Tween<double>(begin: 0.7, end: 1).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack));
    _ctrl.forward();
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (_) => const WelcomePage()));
      }
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: AppColors.gradient),
        child: FadeTransition(
          opacity: _fade,
          child: ScaleTransition(
            scale: _scale,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(0.25),
                          blurRadius: 30,
                          offset: const Offset(0, 10))
                    ],
                  ),
                  child: const Icon(Icons.school_rounded,
                      size: 68, color: AppColors.primary),
                ),
                const SizedBox(height: 28),
                Text('School Exams',
                    style: GoogleFonts.poppins(
                        fontSize: 36,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        letterSpacing: 1)),
                const SizedBox(height: 8),
                Text('Prépare tes examens plus facilement',
                    style:
                        GoogleFonts.poppins(fontSize: 13, color: Colors.white70)),
                const SizedBox(height: 60),
                const CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2.5),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  WIDGETS PARTAGÉS
// ══════════════════════════════════════════════════════
class _LevelCard extends StatelessWidget {
  final String title, subtitle, badge;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _LevelCard(
      {required this.title,
      required this.subtitle,
      required this.badge,
      required this.icon,
      required this.color,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(0.15),
                blurRadius: 16,
                offset: const Offset(0, 6))
          ],
        ),
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              width: 62,
              height: 62,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16)),
              child: Icon(icon, color: color, size: 34),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(title,
                          style: GoogleFonts.poppins(
                              fontSize: 19,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFF1A1A2E))),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                            color: color.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(6)),
                        child: Text(badge,
                            style: GoogleFonts.poppins(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: color)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(subtitle,
                      style: GoogleFonts.poppins(
                          fontSize: 12, color: Colors.grey[600])),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: Colors.grey[400], size: 28),
          ],
        ),
      ),
    );
  }
}

class _SubjectCard extends StatelessWidget {
  final String name;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _SubjectCard(
      {required this.name,
      required this.icon,
      required this.color,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 10,
                offset: const Offset(0, 3))
          ],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(11)),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(name,
                  style: GoogleFonts.poppins(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF1A1A2E))),
            ),
            Icon(Icons.chevron_right_rounded, color: Colors.grey[400], size: 22),
          ],
        ),
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title, subtitle;
  final VoidCallback onTap;
  const _MenuTile(
      {required this.icon,
      required this.color,
      required this.title,
      required this.subtitle,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(0.12),
                blurRadius: 12,
                offset: const Offset(0, 4))
          ],
        ),
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14)),
              child: Icon(icon, color: color, size: 26),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: GoogleFonts.poppins(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: const Color(0xFF1A1A2E))),
                  const SizedBox(height: 2),
                  Text(subtitle,
                      style: GoogleFonts.poppins(
                          fontSize: 12, color: Colors.grey[600])),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: Colors.grey[400], size: 24),
          ],
        ),
      ),
    );
  }
}

class _YearCard extends StatelessWidget {
  final int year;
  final VoidCallback onTap;
  const _YearCard({required this.year, required this.onTap});

  Color get _color {
    if (year >= 2025) return const Color(0xFF1565C0);
    if (year >= 2023) return const Color(0xFF2E7D32);
    return const Color(0xFF795548);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: _color.withOpacity(0.1),
                blurRadius: 12,
                offset: const Offset(0, 4))
          ],
        ),
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                  color: _color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14)),
              child: Icon(Icons.calendar_today_rounded, color: _color, size: 26),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Session $year',
                      style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFF1A1A2E))),
                  Text('Sujet officiel $year',
                      style: GoogleFonts.poppins(
                          fontSize: 12, color: Colors.grey[600])),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                  color: _color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.picture_as_pdf_rounded, color: _color, size: 14),
                  const SizedBox(width: 4),
                  Text('PDF',
                      style: GoogleFonts.poppins(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: _color)),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Icon(Icons.chevron_right_rounded, color: Colors.grey[400], size: 24),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  PAGE BIENVENUE
// ══════════════════════════════════════════════════════
class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});
  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _fade = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeIn));
    _slide = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Widget _featureRow(IconData icon, String label) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: Colors.white, size: 18),
        ),
        const SizedBox(width: 12),
        Expanded(
            child: Text(label,
                style: const TextStyle(fontSize: 13.5, color: Colors.white))),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: AppColors.gradient),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fade,
            child: SlideTransition(
              position: _slide,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 52),
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(26),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 24,
                              offset: const Offset(0, 8))
                        ],
                      ),
                      child: const Icon(Icons.school_rounded,
                          size: 56, color: AppColors.primary),
                    ),
                    const SizedBox(height: 24),
                    Text('School Exams',
                        style: GoogleFonts.poppins(
                            fontSize: 32,
                            fontWeight: FontWeight.w700,
                            color: Colors.white)),
                    const SizedBox(height: 6),
                    Text('Bienvenue sur School Exams 🎓',
                        style: GoogleFonts.poppins(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            color: Colors.white.withOpacity(0.9)),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 4),
                    Text('Prépare tes examens plus facilement.',
                        style: GoogleFonts.poppins(
                            fontSize: 13,
                            color: Colors.white.withOpacity(0.7)),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 36),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: Colors.white.withOpacity(0.2), width: 1.2),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Retrouve :',
                              style: GoogleFonts.poppins(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white)),
                          const SizedBox(height: 16),
                          _featureRow(Icons.description_rounded,
                              'Anciens sujets BAC et BEPC'),
                          const SizedBox(height: 12),
                          _featureRow(
                              Icons.class_rounded, 'Épreuves classées par matière'),
                          const SizedBox(height: 12),
                          _featureRow(
                              Icons.calendar_month_rounded, 'Sujets de 2021 à 2026'),
                          const SizedBox(height: 12),
                          _featureRow(Icons.picture_as_pdf_rounded,
                              'Lecture PDF intégrée dans l\'app'),
                        ],
                      ),
                    ),
                    const Spacer(),
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: () => Navigator.pushReplacement(context,
                            MaterialPageRoute(
                                builder: (_) => const ClassePage())),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: AppColors.primary,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('Continuer',
                                style: GoogleFonts.poppins(
                                    fontSize: 17, fontWeight: FontWeight.w600)),
                            const SizedBox(width: 8),
                            const Icon(Icons.arrow_forward_rounded, size: 20),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 36),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  PAGE CLASSE
// ══════════════════════════════════════════════════════
class ClassePage extends StatelessWidget {
  const ClassePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('School Exams'),
          automaticallyImplyLeading: false),
      body: Column(
        children: [
          _buildSectionHeader(
              '🎓 Choisissez votre classe', 'Sélectionnez votre niveau d\'études'),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _LevelCard(
                  title: '3ème',
                  subtitle: 'Brevet d\'Études du Premier Cycle (BEPC)',
                  icon: Icons.menu_book_rounded,
                  color: const Color(0xFF1565C0),
                  badge: 'BEPC',
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(
                          builder: (_) => const MatierePage(classe: '3ème'))),
                ),
                const SizedBox(height: 16),
                _LevelCard(
                  title: 'Première',
                  subtitle: 'Probatoire — Séries A, C, D',
                  icon: Icons.school_rounded,
                  color: const Color(0xFF2E7D32),
                  badge: 'PROBA',
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(
                          builder: (_) => const SeriePage(niveau: '1ère'))),
                ),
                const SizedBox(height: 16),
                _LevelCard(
                  title: 'Terminale',
                  subtitle: 'Baccalauréat — Séries A, C, D',
                  icon: Icons.workspace_premium_rounded,
                  color: const Color(0xFFE65100),
                  badge: 'BAC',
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(
                          builder: (_) =>
                              const SeriePage(niveau: 'Terminale'))),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


// ══════════════════════════════════════════════════════
//  PAGE À PROPOS
// ══════════════════════════════════════════════════════
class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('À propos')),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 36),
              decoration: const BoxDecoration(gradient: AppColors.gradient),
              child: Column(children: [
                Container(
                  width: 90, height: 90,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [BoxShadow(
                      color: Colors.black26, blurRadius: 20,
                      offset: const Offset(0, 8))],
                  ),
                  child: const Icon(Icons.school_rounded,
                      size: 52, color: AppColors.primary),
                ),
                const SizedBox(height: 16),
                Text('School Exams',
                    style: GoogleFonts.poppins(
                        fontSize: 26, fontWeight: FontWeight.w700,
                        color: Colors.white)),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(20)),
                  child: Text('Version 1.0.0',
                      style: GoogleFonts.poppins(
                          fontSize: 13, color: Colors.white70)),
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(children: [
                _buildAboutCard(
                  icon: Icons.info_rounded,
                  color: AppColors.primary,
                  title: 'Description',
                  lines: [
                    'Application mobile gratuite pour les élèves',
                    'camerounais — BAC et BEPC.',
                    'Anciens sujets classés par niveau, série,',
                    'matière et année.',
                  ],
                ),
                const SizedBox(height: 14),
                _buildAboutCard(
                  icon: Icons.person_rounded,
                  color: const Color(0xFF2E7D32),
                  title: 'Développeur',
                  lines: [
                    'Développé avec passion au Cameroun',
                    'Par Marafa — Développeur Flutter',
                    'Projet dédié aux élèves camerounais',
                  ],
                ),
                const SizedBox(height: 14),
                _buildAboutCard(
                  icon: Icons.description_rounded,
                  color: const Color(0xFF6A1B9A),
                  title: 'Contenu disponible',
                  lines: [
                    '3ème (BEPC)',
                    'Première A, C, D — Probatoire',
                    'Terminale A, C, D — BAC',
                    'Sujets 2021 à 2026 — PDF intégré',
                  ],
                ),
                const SizedBox(height: 14),
                _buildAboutCard(
                  icon: Icons.code_rounded,
                  color: const Color(0xFF0277BD),
                  title: 'Technologie',
                  lines: [
                    'Flutter (Dart) — Android 5.0+',
                    'PDFs hébergés sur Google Drive',
                    'Cache hors-ligne disponible',
                  ],
                ),
                const SizedBox(height: 30),
                Text('School Exams © 2026',
                    style: GoogleFonts.poppins(
                        fontSize: 13, color: Colors.grey)),
                const SizedBox(height: 4),
                Text('Fait avec passion pour les élèves du Cameroun',
                    style: GoogleFonts.poppins(
                        fontSize: 12, color: Colors.grey)),
                const SizedBox(height: 20),
              ]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAboutCard({
    required IconData icon,
    required Color color,
    required String title,
    required List<String> lines,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(
          color: Colors.black.withOpacity(0.05),
          blurRadius: 10,
          offset: const Offset(0, 3))],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.poppins(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF1A1A2E))),
                const SizedBox(height: 6),
                ...lines.map((line) => Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(line,
                      style: GoogleFonts.poppins(
                          fontSize: 13,
                          color: Colors.grey[600],
                          height: 1.5)),
                )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  PAGE MATIÈRES (3ème) — AVEC RECHERCHE ✅
// ══════════════════════════════════════════════════════
class MatierePage extends StatefulWidget {
  final String classe;
  const MatierePage({super.key, required this.classe});
  @override
  State<MatierePage> createState() => _MatierePageState();
}

class _MatierePageState extends State<MatierePage> {
  final TextEditingController _searchCtrl = TextEditingController();
  String _query = '';

  static const List<Map<String, dynamic>> _subjects = [
    {'nom': 'Français', 'icon': Icons.menu_book_rounded, 'color': Color(0xFFE65100)},
    {'nom': 'Mathématiques', 'icon': Icons.calculate_rounded, 'color': Color(0xFF1565C0)},
    {'nom': 'Anglais', 'icon': Icons.language_rounded, 'color': Color(0xFF2E7D32)},
    {'nom': 'PCT', 'icon': Icons.science_rounded, 'color': Color(0xFF6A1B9A)},
    {'nom': 'Histoire-Géographie', 'icon': Icons.public_rounded, 'color': Color(0xFF00695C)},
    {'nom': 'ECM', 'icon': Icons.gavel_rounded, 'color': Color(0xFFC62828)},
    {'nom': 'Informatique', 'icon': Icons.computer_rounded, 'color': Color(0xFF283593)},
    {'nom': 'SVT', 'icon': Icons.biotech_rounded, 'color': Color(0xFF558B2F)},
    {'nom': 'LV2', 'icon': Icons.translate_rounded, 'color': Color(0xFFEF6C00)},
  ];

  List<Map<String, dynamic>> get _filtered => _query.isEmpty
      ? _subjects
      : _subjects
          .where((s) => (s['nom'] as String)
              .toLowerCase()
              .contains(_query.toLowerCase()))
          .toList();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Matières — ${widget.classe}')),
      body: Column(
        children: [
          _buildSectionHeader(
              'Matières — ${widget.classe}', 'Choisissez une matière'),
          _buildSearchBar(
            _searchCtrl,
            'Rechercher une matière...',
            () => setState(() { _searchCtrl.clear(); _query = ''; }),
            (v) => setState(() => _query = v),
          ),
          Expanded(
            child: _filtered.isEmpty
                ? _buildNoResult()
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                    itemCount: _filtered.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, i) {
                      final s = _filtered[i];
                      return _SubjectCard(
                        name: s['nom'] as String,
                        icon: s['icon'] as IconData,
                        color: s['color'] as Color,
                        onTap: () => Navigator.push(context,
                            MaterialPageRoute(
                              builder: (_) => MatiereDetailPage(
                                niveau: '3ème',
                                serie: '',
                                matiere: s['nom'] as String,
                              ),
                            )),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  PAGE SÉRIE
// ══════════════════════════════════════════════════════
class SeriePage extends StatelessWidget {
  final String niveau;
  const SeriePage({super.key, required this.niveau});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> series = [
      {'serie': 'A', 'titre': 'Série A', 'sous': 'Lettres & Sciences Humaines', 'icon': Icons.auto_stories_rounded, 'color': const Color(0xFF6A1B9A)},
      {'serie': 'C', 'titre': 'Série C', 'sous': 'Mathématiques & Physique', 'icon': Icons.calculate_rounded, 'color': const Color(0xFF1565C0)},
      {'serie': 'D', 'titre': 'Série D', 'sous': 'Sciences Naturelles', 'icon': Icons.science_rounded, 'color': const Color(0xFF2E7D32)},
    ];
    return Scaffold(
      appBar: AppBar(title: Text('Série — $niveau')),
      body: Column(
        children: [
          _buildSectionHeader(niveau, 'Choisissez votre série'),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: series.length,
              separatorBuilder: (_, __) => const SizedBox(height: 14),
              itemBuilder: (context, i) {
                final s = series[i];
                return _LevelCard(
                  title: s['titre'] as String,
                  subtitle: s['sous'] as String,
                  icon: s['icon'] as IconData,
                  color: s['color'] as Color,
                  badge: 'Série ${s['serie']}',
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(
                        builder: (_) => MatiereSeriePage(
                            niveau: niveau, serie: s['serie'] as String),
                      )),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  PAGE MATIÈRES PAR SÉRIE — AVEC RECHERCHE ✅
// ══════════════════════════════════════════════════════
class MatiereSeriePage extends StatefulWidget {
  final String niveau, serie;
  const MatiereSeriePage(
      {super.key, required this.niveau, required this.serie});
  @override
  State<MatiereSeriePage> createState() => _MatiereSeriePageState();
}

class _MatiereSeriePageState extends State<MatiereSeriePage> {
  final TextEditingController _searchCtrl = TextEditingController();
  String _query = '';

  List<Map<String, dynamic>> get _subjects {
    if (widget.serie == 'A') {
      return [
        {'nom': 'Littérature', 'icon': Icons.auto_stories_rounded, 'color': const Color(0xFF6A1B9A)},
        {'nom': 'Langue Français', 'icon': Icons.menu_book_rounded, 'color': const Color(0xFFE65100)},
        {'nom': 'Philosophie', 'icon': Icons.psychology_rounded, 'color': const Color(0xFF4527A0)},
        {'nom': 'SVT', 'icon': Icons.biotech_rounded, 'color': const Color(0xFF558B2F)},
        {'nom': 'Histoire', 'icon': Icons.history_edu_rounded, 'color': const Color(0xFF795548)},
        {'nom': 'Géographie', 'icon': Icons.public_rounded, 'color': const Color(0xFF00695C)},
        {'nom': 'ECM', 'icon': Icons.gavel_rounded, 'color': const Color(0xFFC62828)},
        {'nom': 'Anglais', 'icon': Icons.language_rounded, 'color': const Color(0xFF2E7D32)},
        {'nom': 'Mathématiques', 'icon': Icons.calculate_rounded, 'color': const Color(0xFF1565C0)},
        {'nom': 'Informatique', 'icon': Icons.computer_rounded, 'color': const Color(0xFF283593)},
        {'nom': 'LV2', 'icon': Icons.translate_rounded, 'color': const Color(0xFFEF6C00)},
      ];
    } else {
      return [
        {'nom': 'SVT', 'icon': Icons.biotech_rounded, 'color': const Color(0xFF558B2F)},
        {'nom': 'Mathématiques', 'icon': Icons.calculate_rounded, 'color': const Color(0xFF1565C0)},
        {'nom': 'Physique', 'icon': Icons.electrical_services_rounded, 'color': const Color(0xFF0277BD)},
        {'nom': 'Chimie', 'icon': Icons.science_rounded, 'color': const Color(0xFF6A1B9A)},
        {'nom': 'Informatique', 'icon': Icons.computer_rounded, 'color': const Color(0xFF283593)},
        {'nom': 'Histoire', 'icon': Icons.history_edu_rounded, 'color': const Color(0xFF795548)},
        {'nom': 'Géographie', 'icon': Icons.public_rounded, 'color': const Color(0xFF00695C)},
        {'nom': 'ECM', 'icon': Icons.gavel_rounded, 'color': const Color(0xFFC62828)},
        {'nom': 'Anglais', 'icon': Icons.language_rounded, 'color': const Color(0xFF2E7D32)},
        {'nom': 'Philosophie', 'icon': Icons.psychology_rounded, 'color': const Color(0xFF4527A0)},
        {'nom': 'Français', 'icon': Icons.menu_book_rounded, 'color': const Color(0xFFE65100)},
      ];
    }
  }

  List<Map<String, dynamic>> get _filtered => _query.isEmpty
      ? _subjects
      : _subjects
          .where((s) => (s['nom'] as String)
              .toLowerCase()
              .contains(_query.toLowerCase()))
          .toList();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${widget.niveau} — Série ${widget.serie}')),
      body: Column(
        children: [
          _buildSectionHeader(
              '${widget.niveau} · Série ${widget.serie}', 'Choisissez une matière'),
          _buildSearchBar(
            _searchCtrl,
            'Rechercher une matière...',
            () => setState(() { _searchCtrl.clear(); _query = ''; }),
            (v) => setState(() => _query = v),
          ),
          Expanded(
            child: _filtered.isEmpty
                ? _buildNoResult()
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                    itemCount: _filtered.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, i) {
                      final s = _filtered[i];
                      return _SubjectCard(
                        name: s['nom'] as String,
                        icon: s['icon'] as IconData,
                        color: s['color'] as Color,
                        onTap: () => Navigator.push(context,
                            MaterialPageRoute(
                              builder: (_) => MatiereDetailPage(
                                niveau: widget.niveau,
                                serie: widget.serie,
                                matiere: s['nom'] as String,
                              ),
                            )),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  PAGE DÉTAIL MATIÈRE
// ══════════════════════════════════════════════════════
class MatiereDetailPage extends StatelessWidget {
  final String niveau, serie, matiere;
  const MatiereDetailPage(
      {super.key,
      required this.niveau,
      required this.serie,
      required this.matiere});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(matiere)),
      body: Column(
        children: [
          _buildSectionHeader(
              matiere, '$niveau${serie.isNotEmpty ? ' · Série $serie' : ''}'),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const SizedBox(height: 8),
                  _MenuTile(
                    icon: Icons.history_edu_rounded,
                    color: AppColors.primary,
                    title: 'Anciens sujets d\'examen',
                    subtitle: 'Consulte les épreuves des sessions passées',
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(
                          builder: (_) => AnciensSubjetsPage(
                              niveau: niveau, serie: serie, matiere: matiere),
                        )),
                  ),
                  const SizedBox(height: 14),
                  _MenuTile(
                    icon: Icons.edit_note_rounded,
                    color: const Color(0xFF2E7D32),
                    title: 'Épreuves pratiques',
                    subtitle: 'Bientôt disponible',
                    onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Bientôt disponible !'))),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  PAGE ANCIENS SUJETS
// ══════════════════════════════════════════════════════
class AnciensSubjetsPage extends StatelessWidget {
  final String niveau, serie, matiere;
  const AnciensSubjetsPage(
      {super.key,
      required this.niveau,
      required this.serie,
      required this.matiere});

  static const List<int> _years = [2026, 2025, 2024, 2023, 2022, 2021];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sujets — $matiere')),
      body: Column(
        children: [
          _buildSectionHeader(
              matiere, '$niveau${serie.isNotEmpty ? ' · Série $serie' : ''}'),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: _years.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) => _YearCard(
                year: _years[i],
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(
                      builder: (_) => SubjetDetailPage(
                          niveau: niveau,
                          serie: serie,
                          matiere: matiere,
                          annee: _years[i]),
                    )),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  PAGE CONTENU DU SUJET
// ══════════════════════════════════════════════════════
class SubjetDetailPage extends StatelessWidget {
  final String niveau, serie, matiere;
  final int annee;
  const SubjetDetailPage(
      {super.key,
      required this.niveau,
      required this.serie,
      required this.matiere,
      required this.annee});

  static const Map<String, Map<int, String>> _pdfLinks = {
    'Anglais_3ème': {
      2021: 'https://drive.google.com/file/d/196sM7zLVEyUGVPwTWHyjhaKqLHPs9HJ8/view',
      2023: 'https://drive.google.com/file/d/1_xptzaEq_jsig7XmUrx_kU7dtBUwxeIg/view',
      2025: 'https://drive.google.com/file/d/1ApsWgyocbfahRhedFJzR2fG7o1Notptq/view',
    },
    'ECM_3ème': {
      2021: 'https://drive.google.com/file/d/1B_RaQbUwO3fHmwuX0rw-vcZTrOKB1Mhk/view',
      2023: 'https://drive.google.com/file/d/1b8ck3ow4sKzN7k6x2l6LqKk2v_Ab-USi/view',
      2024: 'https://drive.google.com/file/d/1T0YKZr3mLlE-Nc4CauWZ45w_S169K85F/view',
    },
    'Français_3ème': {
      2021: 'https://drive.google.com/file/d/1z9hjyH8728DfMYHHud3RjqqPQ5dos_gJ/view',
      2023: 'https://drive.google.com/file/d/1jHlPqV-fCOq2MPMGm-JJO-uv4wEG3U1b/view',
      2024: 'https://drive.google.com/file/d/1G9ET7KdfUOmU0cMaR3vDBxM80Ihz-VST/view',
      2025: 'https://drive.google.com/file/d/1EgGWJ0rRuQMq2LqPOROamE6sV2yOAEj_/view',
    },
    'Histoire-Géographie_3ème': {
      2021: 'https://drive.google.com/file/d/1XQRu2nebCH94JqrPgNNXSNw2t6Rwyshd/view',
      2023: 'https://drive.google.com/file/d/1jVkyynBZr2zQgUyeM_hCjlefpNNpcELq/view',
      2025: 'https://drive.google.com/file/d/1_XB6MVjvxZVBNaJgC5vz51fdgCDCykrV/view',
    },
    'Informatique_3ème': {
      2021: 'https://drive.google.com/file/d/1aCL1HeWHJOflqCmHeIov6kOH6dmoFwKY/view',
      2023: 'https://drive.google.com/file/d/1KM7Hq_2gCwjrG5cEZDkzU8W0BiP85yap/view',
      2024: 'https://drive.google.com/file/d/1nwmmKai1LdEOwUrr1fHDV03IQ75FYNwc/view',
      2025: 'https://drive.google.com/file/d/1av7RaxzxvcIfsgXzVW7Xb1levH_nXb3R/view',
    },
    'Mathématiques_3ème': {
      2021: 'https://drive.google.com/file/d/1VP94-EvV64Y_h40zctQy4-6DP1iz5qSA/view',
      2023: 'https://drive.google.com/file/d/1mBcrOFkkbU296oKa8FmTQ1t_ZBVETb2H/view',
      2024: 'https://drive.google.com/file/d/1YpBhHmjdUVK_gD9pUNVjos9CIGulY2sR/view',
      2025: 'https://drive.google.com/file/d/1hjErZA7-9WLBFrHZBEMn1Qg2CCBCbmSf/view',
    },
    'PCT_3ème': {
      2021: 'https://drive.google.com/file/d/1moneNKq2fVRStaEbvf8hTo-iv7Z9Ocoa/view',
      2023: 'https://drive.google.com/file/d/1SkIX6Y_UNw00FUBv5l-qkWQ7JIQmiOSU/view',
      2024: 'https://drive.google.com/file/d/1nukca0UF7gxS9xctUkb3_KDuDQ-nU4W0/view',
      2025: 'https://drive.google.com/file/d/1qRpnjuPxUfd5IwrB9uP28oDQRXSVzB72/view',
    },
    'SVT_3ème': {
      2021: 'https://drive.google.com/file/d/1uJmUZacGcYevr_hZip3OU0-p8EAK2piL/view',
      2023: 'https://drive.google.com/file/d/1ToOYRnRi27PSKlqcgr5EISH-2y7O1lHI/view',
      2024: 'https://drive.google.com/file/d/1KW4yiqfCmJ3JqaPhHfOudnP-0PQsHtMi/view',
      2025: 'https://drive.google.com/file/d/1L--RxRUIrjdZVQIRjgkhsePHGN-eeBBG/view',
    },
    'ECM_1ère A': {
      2021: 'https://drive.google.com/file/d/1bKil8-SzowYMMvJLAQU9JeyTD3Y-MQb2/view',
      2023: 'https://drive.google.com/file/d/1czUUFCThAfqZYE9krpnwiJz4AEqfQXfb/view',
      2024: 'https://drive.google.com/file/d/1WxOQieDBKV06Y4YDlbNk1xgRxx6TN7TN/view',
      2025: 'https://drive.google.com/file/d/17nW8xrHztavjW4my1rn2PHcBCYbDK_el/view',
    },
    'Géographie_1ère A': {
      2021: 'https://drive.google.com/file/d/1E4u4dOv2zWyyVSfV_vizNvh0Jx3mUOrX/view',
      2023: 'https://drive.google.com/file/d/1AGhG1bRZ0JPrgvYgMn9mzjDTgDPxlm9E/view',
      2024: 'https://drive.google.com/file/d/1pPjVU4tYWFE3nG7B9yuG7OhBVSUFi7UA/view',
      2025: 'https://drive.google.com/file/d/1rcalQG3qbafw17Cz-YTs1P27DJxVufub/view',
    },
    'Histoire_1ère A': {
      2021: 'https://drive.google.com/file/d/1JR0paw-LyYSziVFCusTe2h43siv624Qg/view',
      2023: 'https://drive.google.com/file/d/1vDfKIZ2iNlkdlE3V2aoeI1TiISh4FK4z/view',
      2024: 'https://drive.google.com/file/d/1eYoecGatG0Fds1jEcFQJziF5DrQTH797/view',
      2025: 'https://drive.google.com/file/d/1RUU3woP0GgHM7PvVX86Ru0skwpJjPc-n/view',
    },
    'Informatique_1ère A': {
      2021: 'https://drive.google.com/file/d/1lB1eknc1_-p_r4A_9XgmXaAwfApKcqQU/view',
      2023: 'https://drive.google.com/file/d/1QzI8UhdXS_ZQ1Frss5nzEL2PdckMrCkZ/view',
      2024: 'https://drive.google.com/file/d/1tqoSG7gxei_XVirLXT64yNSmVSMf9gI9/view',
      2025: 'https://drive.google.com/file/d/1w2OlydoMZ6SEsrO5jDY3aNjQHnVKo6-P/view',
    },
    'Langue Français_1ère A': {
      2021: 'https://drive.google.com/file/d/1NUC0Zlc3Csc9HSZmCVJFaRSbFMa4q0YJ/view',
      2023: 'https://drive.google.com/file/d/176ABEafV1suouyWEDc8zMxHg1DmjEWr3/view',
      2024: 'https://drive.google.com/file/d/1GGMQ7qxsgj2N91JO9EfjPqdarvJV3Ra2/view',
      2025: 'https://drive.google.com/file/d/1vclw345P0BVX3HK1dgZ325uQuLxrXYr9/view',
    },
    'Littérature_1ère A': {
      2023: 'https://drive.google.com/file/d/1SVM4FO4g_DNf-CCvCN6EHVb3eCB6Zj1a/view',
      2024: 'https://drive.google.com/file/d/10x7bbSAnfB-THz_Pz1rrZ4bqAVmFTH1i/view',
      2025: 'https://drive.google.com/file/d/1-Olw5Jqla1SiVnvBv30wgwtEIt_7OEem/view',
    },
    'Mathématiques_1ère A': {
      2021: 'https://drive.google.com/file/d/1-63qBPyUK7bCbMQ-stEa6eUrP1UIURiS/view',
      2023: 'https://drive.google.com/file/d/1OfKjkMreEYBZSwtT2NX1u98PkHqyu18X/view',
      2024: 'https://drive.google.com/file/d/1_jMIgcvslz0_h1ynqAXzwVOq7YnK1nxs/view',
      2025: 'https://drive.google.com/file/d/1sbVz8f3D0FTm2wQ23KWW3yG13-RMvBO-/view',
    },
    'Philosophie_1ère A': {
      2021: 'https://drive.google.com/file/d/1qbk1yLOMEZ-07zRfMpnQqt37RLa0j-9k/view',
      2023: 'https://drive.google.com/file/d/1RSeDqWvEauheWyUYCZiAO9ekRTi2LEEo/view',
      2024: 'https://drive.google.com/file/d/13cby9sMna7TNeGDP4Bok6w8jJOJgiehN/view',
      2025: 'https://drive.google.com/file/d/1AMOIFi0SpOG6nfMySr4lhrr_fAhJkvqY/view',
    },
    'SVT_1ère A': {
      2021: 'https://drive.google.com/file/d/1F7r3F72pPaZwEz75GyxE2RqwQN89EYaz/view',
      2023: 'https://drive.google.com/file/d/1xmgyVBXdm7KHp20ACR2F_kQREq2hI8m0/view',
      2024: 'https://drive.google.com/file/d/1MAy4Kfu7-MMnOMZW8NwSfRsiE3LEGweG/view',
      2025: 'https://drive.google.com/file/d/1h37GzApVT5KlQSxyWa8fiIQa8csn1dv8/view',
    },
    'Anglais_1ère C': {
      2021: 'https://drive.google.com/file/d/1xWcLoudvRve2_GENyPa7-nnOXFidNbEm/view',
      2023: 'https://drive.google.com/file/d/1tgr9ShyIUFFRM8x8hbmCmseTEi-6jNeK/view',
      2024: 'https://drive.google.com/file/d/1bpFWqTUAaH5mEv32nzxKMJGaiYysuC4j/view',
      2025: 'https://drive.google.com/file/d/1UOuJ8Cw3KxypaEKmiFZHwehxK22QSoK4/view',
    },
    'Chimie_1ère C': {
      2021: 'https://drive.google.com/file/d/1wekvnkmyje5PCmjTHmpyEx5oEf1TzmAl/view',
      2023: 'https://drive.google.com/file/d/1hj2MZpxIJK58dTdH5-RYjXkqabTj2rhS/view',
      2024: 'https://drive.google.com/file/d/1s2r9cQ_Dq9d1Nr7Aq-jsX4HglzxZ-XCr/view',
      2025: 'https://drive.google.com/file/d/1_ytVe-F9i0JR-tNU2Z0lF4enmQhvsFB4/view',
    },
    'ECM_1ère C': {
      2021: 'https://drive.google.com/file/d/1vD753o2mGZguNE6wLvchZFhlheZBytrw/view',
      2023: 'https://drive.google.com/file/d/10TwLwB5oln3I_9MGIsvNaEsXywOysQ27/view',
      2024: 'https://drive.google.com/file/d/1V-4jsbumjs8iBWrhaXxhQUiBMvk5eQgQ/view',
      2025: 'https://drive.google.com/file/d/12wr4uj8tuTVLd6Y-I2y43zXyPFqciyDB/view',
    },
    'Histoire_1ère C': {
      2021: 'https://drive.google.com/file/d/1Xd0Uzneiu1-Xl8Vlvx6X6UWAX3seFRcX/view',
      2023: 'https://drive.google.com/file/d/1YJRvJkD0U3ro3DB617E86MhDuANJVX2v/view',
      2024: 'https://drive.google.com/file/d/1h9arvqBdtuaBfh-dz-ze7qsWOjNcMjjz/view',
      2025: 'https://drive.google.com/file/d/1ghgBxV6Bi8Y_uSsBOkdHHhYC1W7ns0y6/view',
    },
    'Informatique_1ère C': {
      2021: 'https://drive.google.com/file/d/1HhZrQ4kyilWCMZEbMaDqBeuhml6KKSrw/view',
      2023: 'https://drive.google.com/file/d/1Exe-IrNoT11WpB80zzxZxM3OXwGDnSFZ/view',
      2024: 'https://drive.google.com/file/d/1-gEDnb7qvlsSeZpCI5-y5mV7RdAMqhNW/view',
      2025: 'https://drive.google.com/file/d/1kpnLP2KZ9j8Z8-yGUp-mjntq7ecIWRb2/view',
    },
    'Mathématiques_1ère C': {
      2021: 'https://drive.google.com/file/d/1S_yaAJofYnGf5TFnPY9pLas3OnnqHTq4/view',
      2024: 'https://drive.google.com/file/d/1rpAPYj_v2nSVqDAGnKnjwVnJ4jEBIWc7/view',
      2025: 'https://drive.google.com/file/d/14J6QhJX407POJd4icLzr9uK0OQSxzU3z/view',
    },
    'Philosophie_1ère C': {
      2021: 'https://drive.google.com/file/d/1aoQEq8BdFXOnxKw0so61ek5cFweRSozM/view',
      2023: 'https://drive.google.com/file/d/1oojTPAMTKZjM1BinkeoKtgCsXS6aOT5u/view',
      2024: 'https://drive.google.com/file/d/1Rm--TvlJmjFQ9BL5Vp49eKP1o_wbwJ-G/view',
      2025: 'https://drive.google.com/file/d/1EAYOATT7QSM--TGuRzH7ckrtNnlKVEra/view',
    },
    'Physique_1ère C': {
      2021: 'https://drive.google.com/file/d/1f5-sEaz_0B1xdmb4cwiwRuUGRUqvxPIR/view',
      2023: 'https://drive.google.com/file/d/1qMwmwzU9nh2pcyMEEtdDlD_mo5lad95u/view',
      2024: 'https://drive.google.com/file/d/1qDpr05-mWVN6GBBHkndx94cnwkRMW9I6/view',
      2025: 'https://drive.google.com/file/d/1nMiiljoEaOAMIY7cbpANZYcdn5BO7OC3/view',
    },
    'SVT_1ère C': {
      2021: 'https://drive.google.com/file/d/1XXotWIoUWOA5Rni9PxRZNDNPgW_a_jjB/view',
      2023: 'https://drive.google.com/file/d/1VP9qJ3T89XTtOoGVrvXFbtH2mSLyLHT4/view',
      2024: 'https://drive.google.com/file/d/1iIe3BwGYREgAYPGx5nsi0iK0OGPgdhmr/view',
      2025: 'https://drive.google.com/file/d/1hPGAyT9fGdZMm6ttEzpSpAxNY-o4BcWj/view',
    },
    'Anglais_1ère D': {
      2021: 'https://drive.google.com/file/d/1R5WwKnsCfmlnO3XrQgkQV3dY4pifbQFG/view',
      2023: 'https://drive.google.com/file/d/11SO1iE2Svr5-LIEc4LTo31eGacyY0Jvw/view',
      2024: 'https://drive.google.com/file/d/1pA2T975YXMu-44SOK0EOTRUP_og_-vML/view',
      2025: 'https://drive.google.com/file/d/1DYQHVv0H4zADkdMhXDidWudISOnKgwMO/view',
    },
    'Chimie_1ère D': {
      2021: 'https://drive.google.com/file/d/1xot4SRsix2EiWqG-nFZq437iwO1xwUFg/view',
      2023: 'https://drive.google.com/file/d/1h5scXUQmkyVNM2ht754RWDR26rfpTwJM/view',
      2024: 'https://drive.google.com/file/d/146Nj5QDTouXnO33qP3E204X4KKENKPcW/view',
      2025: 'https://drive.google.com/file/d/1y_gQxbrXbUaEgJ3vzeIdceN3eJcCPSKK/view',
    },
    'ECM_1ère D': {
      2021: 'https://drive.google.com/file/d/1PynQqS0EwGjhCCzfh4LHdNb0FhlEB1vU/view',
      2023: 'https://drive.google.com/file/d/1KU5xfH9WhFvga-T7Ok3altKwEmGP0ZqC/view',
      2024: 'https://drive.google.com/file/d/1vKikZkugFlkNpTfV8yS38qk7Cyuwivmq/view',
      2025: 'https://drive.google.com/file/d/1EEiMeEoeII8EIOBLnkOFmnWFRzHdIZSp/view',
    },
    'Histoire_1ère D': {
      2021: 'https://drive.google.com/file/d/1Xd0Uzneiu1-Xl8Vlvx6X6UWAX3seFRcX/view',
      2023: 'https://drive.google.com/file/d/1YJRvJkD0U3ro3DB617E86MhDuANJVX2v/view',
      2024: 'https://drive.google.com/file/d/1h9arvqBdtuaBfh-dz-ze7qsWOjNcMjjz/view',
      2025: 'https://drive.google.com/file/d/1ghgBxV6Bi8Y_uSsBOkdHHhYC1W7ns0y6/view',
    },
    'Informatique_1ère D': {
      2021: 'https://drive.google.com/file/d/1HhZrQ4kyilWCMZEbMaDqBeuhml6KKSrw/view',
      2023: 'https://drive.google.com/file/d/1Exe-IrNoT11WpB80zzxZxM3OXwGDnSFZ/view',
      2024: 'https://drive.google.com/file/d/1-gEDnb7qvlsSeZpCI5-y5mV7RdAMqhNW/view',
      2025: 'https://drive.google.com/file/d/1kpnLP2KZ9j8Z8-yGUp-mjntq7ecIWRb2/view',
    },
    'Mathématiques_1ère D': {
      2021: 'https://drive.google.com/file/d/1zG91lgIMmxRfDPtwF-TpIGP-2qbOOgaF/view',
      2023: 'https://drive.google.com/file/d/1ZIrF3bmNu0yW4sEQWl-W2c2l1egS3m9L/view',
      2024: 'https://drive.google.com/file/d/1ADfL3n4oouMR-lkHWW6ucDWxkzVvARPl/view',
      2025: 'https://drive.google.com/file/d/1gi_xw-cPIkShgKTunyV5rVxfJOtzO45M/view',
    },
    'Philosophie_1ère D': {
      2021: 'https://drive.google.com/file/d/1aoQEq8BdFXOnxKw0so61ek5cFweRSozM/view',
      2023: 'https://drive.google.com/file/d/1oojTPAMTKZjM1BinkeoKtgCsXS6aOT5u/view',
      2024: 'https://drive.google.com/file/d/1Rm--TvlJmjFQ9BL5Vp49eKP1o_wbwJ-G/view',
      2025: 'https://drive.google.com/file/d/1EAYOATT7QSM--TGuRzH7ckrtNnlKVEra/view',
    },
    'Physique_1ère D': {
      2021: 'https://drive.google.com/file/d/1ulYrosXUVESCQwl5qFkY2wyvYFdab-D7/view',
      2023: 'https://drive.google.com/file/d/1Fdi2YE1a7hDoEZNE9ABMgzDMOoh1NEEq/view',
      2024: 'https://drive.google.com/file/d/14Oi47o_IN_JXp2ZJTCYduKMBZYG_80jv/view',
      2025: 'https://drive.google.com/file/d/1rne3QctUFpt29EwteY5Qh_gyWhjPZj4w/view',
    },
    'SVT_1ère D': {
      2021: 'https://drive.google.com/file/d/1HlKzd0OW1PbzYm9tihelD1V6knmBDsat/view',
      2023: 'https://drive.google.com/file/d/1uQp2vrTqolwESmKyGAprSVlZNJe89_YJ/view',
      2025: 'https://drive.google.com/file/d/1dh581r1Vaj5VT7lCLo0OLzxf5RZKhJ40/view',
    },
    'Anglais_Terminale A': {
      2021: 'https://drive.google.com/file/d/1gN8EbAS93SSygxGeYqaqvbJOAwVle8bZ/view',
      2023: 'https://drive.google.com/file/d/1qBaEdO92ne5J5ymDFzt5HQ_mziN6Ngvm/view',
      2024: 'https://drive.google.com/file/d/14nrIIEcKTAW8McHEzjV3Xe6Of9o2cAtR/view',
      2025: 'https://drive.google.com/file/d/12o6WCqB0kKneDalCDd0taMz93LD313yI/view',
    },
    'ECM_Terminale A': {
      2024: 'https://drive.google.com/file/d/1OIOweivyjjviLjPGrSLi12lMVU5WLu-f/view',
      2025: 'https://drive.google.com/file/d/1-blIXquKz_7p_5bXuRWwdvNzp-9j2FHW/view',
    },
    'Géographie_Terminale A': {
      2021: 'https://drive.google.com/file/d/1PPnbIkuaLyPyQZdk_rNmkYb2AHMFxKFo/view',
      2023: 'https://drive.google.com/file/d/14FDFgaF2sOtiaTn1zmgcRM3yXnBJpS6J/view',
      2024: 'https://drive.google.com/file/d/1jrSjjebQNm-pX8J5kxcZq8kNUxQRrdEV/view',
      2025: 'https://drive.google.com/file/d/1zAIU6PdSw1bVYcVEtFN3fYSBCz9zZEQG/view',
    },
    'Histoire_Terminale A': {
      2021: 'https://drive.google.com/file/d/1WW-4j0Nfw-in3Lnc-KCrWqE7e_ckrshk/view',
      2023: 'https://drive.google.com/file/d/16duEhg3aKadHK8X1L-OtNBxejvMlj3w9/view',
      2024: 'https://drive.google.com/file/d/1p6Ma97e_j0581ZHAWWNUKKQYgBUN4hl3/view',
      2025: 'https://drive.google.com/file/d/14t4cWdIA0bJancZCYi070FXam6cdEvdu/view',
    },
    'Informatique_Terminale A': {
      2021: 'https://drive.google.com/file/d/1kYdmyvVCQ_WzD3ZYepj5pE8u3PNnYyKt/view',
      2023: 'https://drive.google.com/file/d/1rc_0CqsOYug6aMYvAA4U_QdeVelBNYah/view',
      2024: 'https://drive.google.com/file/d/1VGnt91bhOEljhiQ2Gg8cZQcLRQlgRuLE/view',
      2025: 'https://drive.google.com/file/d/1q4eLY5o2VPDwy6Fsc1PS1c0uehx0Qp-k/view',
    },
    'Langue Français_Terminale A': {
      2021: 'https://drive.google.com/file/d/1x6bM6_fB00ni1FGEGoL1et5v1xEuYnjJ/view',
      2023: 'https://drive.google.com/file/d/1ycSEPNYEaWGDnR0XPY3MXK6rKO35k1PL/view',
      2024: 'https://drive.google.com/file/d/1eECnZv-ydo3oRs23yzpl0Unbkv7LFw-a/view',
      2025: 'https://drive.google.com/file/d/1FdpCw5RDDYsP1sBoRM9AGce_J-pvVxRN/view',
    },
    'Littérature_Terminale A': {
      2021: 'https://drive.google.com/file/d/1Dbb3lXfbnfyY3WCijghd3AsuoptcFbdm/view',
      2023: 'https://drive.google.com/file/d/1SzvM4ipDC6qa5bbPfGNvepIpNqH74YMb/view',
      2024: 'https://drive.google.com/file/d/1FdtibKXphxoWhJ061e4hhUi4PuZq_ZBi/view',
      2025: 'https://drive.google.com/file/d/1tj9VS6aFajg3DLCb7xCr9GjFnM87dHkD/view',
    },
    'Mathématiques_Terminale A': {
      2021: 'https://drive.google.com/file/d/13bgGZpSwRrXImLZ9XVLoNUFAqmWw1iCa/view',
      2023: 'https://drive.google.com/file/d/1GIAZMKwHiSyQt2RE7cABoHMGQ1qq_xE7/view',
      2024: 'https://drive.google.com/file/d/1xA1NM3u2UzkKJWLhYkiw_I4MRrGBXzK6/view',
      2025: 'https://drive.google.com/file/d/1L1wXFO8ax6lsDl-Q84ID91ais8R3sjEW/view',
    },
    'Philosophie_Terminale A': {
      2021: 'https://drive.google.com/file/d/1cJCeBZjD0UYjYRBs9p4v_i1_aOAe-kau/view',
      2023: 'https://drive.google.com/file/d/1zMK0J4hupmrRMcnYjKhoEI2WK36G8uLj/view',
      2024: 'https://drive.google.com/file/d/1qUjJBCSXHYptOAHD-veaJ-lSXl7HEv97/view',
      2025: 'https://drive.google.com/file/d/1tlqu50ps3xE8wt5nbbh-2Ys-HACgBqkM/view',
    },
    'SVT_Terminale A': {
      2021: 'https://drive.google.com/file/d/1okTXbD781M3Ar3JYWteoSM9vovdLaXDC/view',
      2023: 'https://drive.google.com/file/d/1GwY9RyQx3oBPHSEk67AOQvKjhjqlV_Gt/view',
      2024: 'https://drive.google.com/file/d/1bz8TBWPpYqSb0sKWq2luCgU6oUcRFp35/view',
      2025: 'https://drive.google.com/file/d/1ki-J1zZ5YZGsB3PZBFA2ktU_FiN469wt/view',
    },
    'Anglais_Terminale C': {
      2021: 'https://drive.google.com/file/d/1gNDsesBA1zfJ3boWYtiuvvoMXncuhiMi/view',
      2023: 'https://drive.google.com/file/d/1dh04QbbxYrRJOP1LkFsXW7tHtYIOeeqz/view',
      2025: 'https://drive.google.com/file/d/1KYFmPXoVawyWGpo558CCTS0lXJMRW4On/view',
    },
    'Chimie_Terminale C': {
      2021: 'https://drive.google.com/file/d/1dkoBe5xjW81Lxn6xKfWzMGjMicRP2rRW/view',
      2023: 'https://drive.google.com/file/d/1UUGWMBMCJ9U-yHkQG7Ck6SdNGrNWTaQz/view',
      2024: 'https://drive.google.com/file/d/14uVPrf4qmeJDGYReOVjm4CXXVoFZ15XJ/view',
      2025: 'https://drive.google.com/file/d/1W2YoGqnbrWXSESAKDcHD5PHq6US7gY3Q/view',
    },
    'ECM_Terminale C': {
      2024: 'https://drive.google.com/file/d/1Zdnu-yP_Ec9HuQKI4onqZVKc8MC0bgj4/view',
      2025: 'https://drive.google.com/file/d/1l0kqNwkuOMOopqWFvRStrTB0urKm8fak/view',
    },
    'Français_Terminale C': {
      2023: 'https://drive.google.com/file/d/1dUwpWd8SrQBbrpzuWad8ymv84tS_PSD2/view',
      2024: 'https://drive.google.com/file/d/1jj-W-s9qOHm_5i7iVRw1t1K_jVwi8iNP/view',
    },
    'Géographie_Terminale C': {
      2021: 'https://drive.google.com/file/d/1tAQHYondLncvijubpzzQauUF_wkc6U2a/view',
      2023: 'https://drive.google.com/file/d/1g-oTaJFLu_fNdhAZ9r5LtK4L_sXlCmE_/view',
      2024: 'https://drive.google.com/file/d/1K0kGAFJj2nWfJUcoPh-jXYTgj1a-5le5/view',
      2025: 'https://drive.google.com/file/d/1pLxSxD6xf7Wvr2jD7_bto9URVgsHbGUn/view',
    },
    'Informatique_Terminale C': {
      2021: 'https://drive.google.com/file/d/1kCQuv842MYWW6rzxSlNLHRBbohvE2Vlq/view',
      2023: 'https://drive.google.com/file/d/1aj6Ts8aJTnmOH8VY3r8HdpsBWPLlHbLC/view',
      2024: 'https://drive.google.com/file/d/1U07556T1aWu4kuL7shS_d-ZhZWhog4Vn/view',
      2025: 'https://drive.google.com/file/d/1lESzVUGHd5IzMrY9WuvZVLOQyHbZzgkr/view',
    },
    'Mathématiques_Terminale C': {
      2023: 'https://drive.google.com/file/d/1LbiC4GdojgNmuvRhFRHAdwFdmo3pZ_Jp/view',
      2024: 'https://drive.google.com/file/d/1F6LEjmbxay7q2ihMFt6svmizKmuYhLQZ/view',
      2025: 'https://drive.google.com/file/d/1uJ4lZvvobjV5RlJ3McY6Gvm5OCITvYkk/view',
      2026: 'https://drive.google.com/file/d/129UvD3n3eDuoRY7AFXW3lhRyRNBcBWvv/view',
    },
    'Philosophie_Terminale C': {
      2021: 'https://drive.google.com/file/d/1LFKuAbKGqrZyOGTzZ2dxhupexbX5vjpq/view',
      2023: 'https://drive.google.com/file/d/1L1M9Ofy0kl-bpQyYTFHvqQi_uIej7d9w/view',
      2024: 'https://drive.google.com/file/d/1H3lukD3vEaUfAGgKyJnFN4IUL888HAdF/view',
      2025: 'https://drive.google.com/file/d/1NsjdVgfCZ6DVBTuPhknss9N4CGx8RkLT/view',
    },
    'Physique_Terminale C': {
      2021: 'https://drive.google.com/file/d/1tYgyTsA4eCSweGpzu7wK4h2v43Z19zGw/view',
      2023: 'https://drive.google.com/file/d/1R8i7HgqoUBEuAW5AKlRWAE8f8DYiOp80/view',
      2024: 'https://drive.google.com/file/d/1NEkcQUdF1tBV1Dh0wdP73p9F-9wS5MZ_/view',
      2025: 'https://drive.google.com/file/d/1x4-IaMhyvHQ9fS7QQ1qK11olcevOse17/view',
    },
    'SVT_Terminale C': {
      2021: 'https://drive.google.com/file/d/1YZfT-bzRVq4je4YwlXq7uAiElDfj9DGd/view',
      2023: 'https://drive.google.com/file/d/1gd_eC5GrtFteZKGUZUw31U_TImYzuKMb/view',
      2024: 'https://drive.google.com/file/d/1_yEGD8YwMMpJ2dAxCgZB7nNKZdxJtJKi/view',
      2025: 'https://drive.google.com/file/d/1efitowkclWiZKTFyV4u7qHySXN0JzhNL/view',
    },
    'Anglais_Terminale D': {
      2021: 'https://drive.google.com/file/d/1gNDsesBA1zfJ3boWYtiuvvoMXncuhiMi/view',
      2023: 'https://drive.google.com/file/d/1dh04QbbxYrRJOP1LkFsXW7tHtYIOeeqz/view',
      2025: 'https://drive.google.com/file/d/1KYFmPXoVawyWGpo558CCTS0lXJMRW4On/view',
    },
    'Chimie_Terminale D': {
      2021: 'https://drive.google.com/file/d/1dkoBe5xjW81Lxn6xKfWzMGjMicRP2rRW/view',
      2023: 'https://drive.google.com/file/d/1UUGWMBMCJ9U-yHkQG7Ck6SdNGrNWTaQz/view',
      2024: 'https://drive.google.com/file/d/14uVPrf4qmeJDGYReOVjm4CXXVoFZ15XJ/view',
      2025: 'https://drive.google.com/file/d/1W2YoGqnbrWXSESAKDcHD5PHq6US7gY3Q/view',
    },
    'ECM_Terminale D': {
      2024: 'https://drive.google.com/file/d/1Zdnu-yP_Ec9HuQKI4onqZVKc8MC0bgj4/view',
      2025: 'https://drive.google.com/file/d/1l0kqNwkuOMOopqWFvRStrTB0urKm8fak/view',
    },
    'Français_Terminale D': {
      2023: 'https://drive.google.com/file/d/1dUwpWd8SrQBbrpzuWad8ymv84tS_PSD2/view',
      2024: 'https://drive.google.com/file/d/1jj-W-s9qOHm_5i7iVRw1t1K_jVwi8iNP/view',
    },
    'Géographie_Terminale D': {
      2021: 'https://drive.google.com/file/d/1tAQHYondLncvijubpzzQauUF_wkc6U2a/view',
      2023: 'https://drive.google.com/file/d/1g-oTaJFLu_fNdhAZ9r5LtK4L_sXlCmE_/view',
      2024: 'https://drive.google.com/file/d/1K0kGAFJj2nWfJUcoPh-jXYTgj1a-5le5/view',
      2025: 'https://drive.google.com/file/d/1pLxSxD6xf7Wvr2jD7_bto9URVgsHbGUn/view',
    },
    'Mathématiques_Terminale D': {
      2021: 'https://drive.google.com/file/d/1g5-k0JX7ABn1NMzsIctXPmzBP1EJvYYY/view',
      2024: 'https://drive.google.com/file/d/1dBjueEm6Fo7_itFwFJMxl8eFq1vPT1lP/view',
      2025: 'https://drive.google.com/file/d/1j4H2Aw6SrOC0JgYW3-SGo2RSMqqaMNwP/view',
    },
    'Philosophie_Terminale D': {
      2021: 'https://drive.google.com/file/d/1LFKuAbKGqrZyOGTzZ2dxhupexbX5vjpq/view',
      2023: 'https://drive.google.com/file/d/1L1M9Ofy0kl-bpQyYTFHvqQi_uIej7d9w/view',
      2024: 'https://drive.google.com/file/d/1H3lukD3vEaUfAGgKyJnFN4IUL888HAdF/view',
      2025: 'https://drive.google.com/file/d/1NsjdVgfCZ6DVBTuPhknss9N4CGx8RkLT/view',
    },
    'Physique_Terminale D': {
      2021: 'https://drive.google.com/file/d/15lashBiXTIRP716cHH45-UL4hH41XAV_/view',
      2023: 'https://drive.google.com/file/d/1DxcYaG2mFstEI_aH1oj7eNMOALTkolTW/view',
      2024: 'https://drive.google.com/file/d/1lxzZGmgnmYCJvabOwostu3kNN85f-uZc/view',
      2025: 'https://drive.google.com/file/d/1cDYnKaMUcxm4vJr_H_gHJjxGD60OrPDl/view',
    },
    'SVT_Terminale D': {
      2021: 'https://drive.google.com/file/d/1ChcSavRH_D4-T5aXohSj1PD-Rva1F2W2/view',
      2023: 'https://drive.google.com/file/d/1S6TS9fcQn0OajvYrNv2qPJNiYmPJxuRt/view',
      2024: 'https://drive.google.com/file/d/14un5n-Bw9Y_W11fTtHoOMwuFyyXeU7v9/view',
      2025: 'https://drive.google.com/file/d/1rhepBQ1M6Dm7hbmonahHUngDcVynSz2k/view',
    },
  };

  String? get _pdfUrl {
    final key = '${matiere}_$niveau${serie.isNotEmpty ? ' $serie' : ''}';
    return _pdfLinks[key]?[annee];
  }

  Widget _row(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: GoogleFonts.poppins(fontSize: 12, color: Colors.white60)),
        Flexible(
          child: Text(value,
              style: GoogleFonts.poppins(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Colors.white),
              textAlign: TextAlign.right),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final pdfUrl = _pdfUrl;
    return Scaffold(
      appBar: AppBar(title: Text('$matiere — $annee')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [Color(0xFF0D1B6E), Color(0xFF1565C0)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                children: [
                  const Icon(Icons.school_rounded,
                      color: Colors.white, size: 42),
                  const SizedBox(height: 12),
                  Text('RÉPUBLIQUE DU CAMEROUN',
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          color: Colors.white),
                      textAlign: TextAlign.center),
                  Text('MINISTÈRE DES ENSEIGNEMENTS SECONDAIRES',
                      style: GoogleFonts.poppins(
                          fontSize: 11, color: Colors.white70),
                      textAlign: TextAlign.center),
                  const Divider(color: Colors.white24, height: 24),
                  _row('EXAMEN',
                      '$niveau${serie.isNotEmpty ? ' · Série $serie' : ''}'),
                  const SizedBox(height: 6),
                  _row('SESSION', '$annee'),
                  const SizedBox(height: 6),
                  _row('MATIÈRE', matiere.toUpperCase()),
                ],
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: pdfUrl != null
                    ? () => Navigator.push(context,
                            MaterialPageRoute(
                              builder: (_) => PdfViewerPage(
                                title: '$matiere · Série $serie · $annee',
                                pdfUrl: pdfUrl,
                              ),
                            ))
                    : null,
                icon: const Icon(Icons.picture_as_pdf_rounded, size: 22),
                label: Text(
                    pdfUrl != null
                        ? 'Ouvrir le sujet PDF'
                        : 'PDF bientôt disponible',
                    style: GoogleFonts.poppins(
                        fontSize: 16, fontWeight: FontWeight.w600)),
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      pdfUrl != null ? AppColors.primary : Colors.grey[400],
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
              ),
            ),
            if (pdfUrl == null) ...[
              const SizedBox(height: 16),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.orange.shade200),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline_rounded,
                        color: Colors.orange.shade700),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                          'Ce sujet sera disponible prochainement. Revenez bientôt !',
                          style: GoogleFonts.poppins(
                              fontSize: 13, height: 1.5)),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  PAGE PDF VIEWER (avec cache)
// ══════════════════════════════════════════════════════
class PdfViewerPage extends StatefulWidget {
  final String title, pdfUrl;
  const PdfViewerPage(
      {super.key, required this.title, required this.pdfUrl});
  @override
  State<PdfViewerPage> createState() => _PdfViewerPageState();
}

class _PdfViewerPageState extends State<PdfViewerPage> {
  String? _localPath;
  bool _isLoading = true, _hasError = false;
  String _errorMsg = '';
  int _currentPage = 0, _totalPages = 0;
  PDFViewController? _ctrl;

  @override
  void initState() {
    super.initState();
    _loadPDF();
  }

  String _toDirectUrl(String url) {
    if (url.contains('drive.google.com/file/d/')) {
      final m = RegExp(r'/file/d/([^/?\s]+)').firstMatch(url);
      if (m != null)
        return 'https://drive.google.com/uc?export=download&id=${m.group(1)}';
    }
    return url;
  }

  Future<void> _loadPDF() async {
    setState(() { _isLoading = true; _hasError = false; });
    try {
      final cacheKey = widget.pdfUrl.hashCode.abs().toString();
      final dir = await getTemporaryDirectory();
      final cachedFile = File('${dir.path}/pdf_$cacheKey.pdf');

      if (await cachedFile.exists()) {
        if (mounted) setState(() { _localPath = cachedFile.path; _isLoading = false; });
        return;
      }

      final url = _toDirectUrl(widget.pdfUrl);
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 30));

      if (res.statusCode == 200) {
        await cachedFile.writeAsBytes(res.bodyBytes);
        if (mounted) setState(() { _localPath = cachedFile.path; _isLoading = false; });
      } else {
        _fail('Erreur serveur (code ${res.statusCode})');
      }
    } on SocketException {
      _fail('Aucune connexion internet');
    } catch (_) {
      _fail('Impossible de charger le sujet.\nVérifiez votre connexion.');
    }
  }

  void _fail(String msg) {
    if (mounted) setState(() { _hasError = true; _errorMsg = msg; _isLoading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.title,
                style: GoogleFonts.poppins(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.white),
                maxLines: 1,
                overflow: TextOverflow.ellipsis),
            if (_totalPages > 0)
              Text('Page ${_currentPage + 1} / $_totalPages',
                  style: GoogleFonts.poppins(
                      fontSize: 11, color: Colors.white70)),
          ],
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(
                color: AppColors.primary, strokeWidth: 3),
            const SizedBox(height: 20),
            Text('Chargement du sujet…',
                style: GoogleFonts.poppins(
                    fontSize: 15, color: AppColors.primary)),
            const SizedBox(height: 6),
            Text('Cela peut prendre quelques secondes',
                style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey)),
          ],
        ),
      );
    }
    if (_hasError) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.cloud_off_rounded,
                  size: 72, color: Colors.redAccent),
              const SizedBox(height: 16),
              Text('Impossible d\'ouvrir le sujet',
                  style: GoogleFonts.poppins(
                      fontSize: 17, fontWeight: FontWeight.w600),
                  textAlign: TextAlign.center),
              const SizedBox(height: 8),
              Text(_errorMsg,
                  style: GoogleFonts.poppins(
                      fontSize: 13, color: Colors.grey[600]),
                  textAlign: TextAlign.center),
              const SizedBox(height: 28),
              ElevatedButton.icon(
                onPressed: _loadPDF,
                icon: const Icon(Icons.refresh_rounded),
                label: Text('Réessayer', style: GoogleFonts.poppins()),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 28, vertical: 13),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ],
          ),
        ),
      );
    }
    return Stack(
      children: [
        PDFView(
          filePath: _localPath!,
          enableSwipe: true,
          swipeHorizontal: false,
          autoSpacing: true,
          pageFling: true,
          fitPolicy: FitPolicy.BOTH,
          onRender: (pages) => setState(() => _totalPages = pages ?? 0),
          onViewCreated: (c) => _ctrl = c,
          onPageChanged: (p, _) {
            if (p != null) setState(() => _currentPage = p);
          },
          onError: (_) => _fail('Erreur lors de l\'affichage du PDF'),
        ),
        if (_totalPages > 1)
          Positioned(
            bottom: 16, left: 0, right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.65),
                    borderRadius: BorderRadius.circular(30)),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    GestureDetector(
                      onTap: _currentPage > 0
                          ? () => _ctrl?.setPage(_currentPage - 1)
                          : null,
                      child: Icon(Icons.chevron_left,
                          size: 30,
                          color: _currentPage > 0
                              ? Colors.white
                              : Colors.white30),
                    ),
                    const SizedBox(width: 16),
                    Text('${_currentPage + 1} / $_totalPages',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 14)),
                    const SizedBox(width: 16),
                    GestureDetector(
                      onTap: _currentPage < _totalPages - 1
                          ? () => _ctrl?.setPage(_currentPage + 1)
                          : null,
                      child: Icon(Icons.chevron_right,
                          size: 30,
                          color: _currentPage < _totalPages - 1
                              ? Colors.white
                              : Colors.white30),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}
